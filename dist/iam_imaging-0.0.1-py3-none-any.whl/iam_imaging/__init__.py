from matplotlib.pyplot import imread,imsave
def image_read(f):
    return imread(f)

def image_save(f,im):
    return imsave(f,im)

def pre_processing(im):
    return im
def processing(im):
    return im
def post_processing(im):
    return im